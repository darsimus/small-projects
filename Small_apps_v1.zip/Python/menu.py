from tkinter import *
from tkinter import ttk
from tkinter.filedialog import askopenfilename
from tkinter import messagebox
import os
import webbrowser
import sys
root=Tk()
root.title("Main Window")



if sys.argv:
    filepath = sys.argv[0]
    folder, filename = os.path.split(filepath)
    os.chdir(folder)


class ASwin(Toplevel):
    def __init__(self,parent):
        super().__init__(parent)






def calculator(): # run calculator app
    calculate=ASwin(root) #set up top level window
    calculate.title('Calculator') # set up title for toplevel window
    calculate.geometry('246x230') # set up top level window size size
    entry_field = Entry(calculate, borderwidth=5, width=38,justify='right' )
    entry_field.grid(row=1 , column=0)
    entry_field.insert(0,0)
    global m_num
    global result
    global active
    global m_num
    global Memlist
    m_num=0
    active=0
    result="non"
    Memlist =[]

    Frame0=LabelFrame(calculate)
    Frame0.grid(row=2, column=0)

    def take_from_memlist(value):
        if float(entry_field.get())==0:
            entry_field.delete(0, END)
        current=entry_field.get()
        entry_field.delete(0, END)
        entry_field.insert(0, str(current) +str(value))
    def button_MR():
        entry_field.delete(0, END)
        entry_field.insert(0, CalcMemory)
    def button_MS():
        save_number = entry_field.get()
        global Memlist
        global CalcMemory
        CalcMemory=save_number
        if len(Memlist)==5:
            Memlist.pop(0)
        Memlist.append(save_number)

    def button_Mplus():
        global CalcMemory
        number_current = entry_field.get()
        CalcMemory=(float(CalcMemory) + float(number_current))
        Memlist[0]=str(float(Memlist[0])+float(number_current))
    def button_Mminus():
        global CalcMemory
        number_current = entry_field.get()
        CalcMemory=float(CalcMemory) - float(number_current)
        Memlist[0]=str(float(Memlist[0])-float(number_current))
    def button_Mstar():
        global Memlist
        global active
        if active==0:
            myFrame2.config(height=165, width=246)
            myFrame2.grid(row=3, column=0 )
            Frame.grid_forget()
            active=1
            for i in range(len(Memlist)):
                butName= Button(myFrame2, text = Memlist[i],width=32, command=lambda x=Memlist[i]:take_from_memlist(x)).grid(row = i, column = 0)

        else:
            myFrame2.grid_forget()
            Frame.grid(row=3, column=0)
            active=0
        
    def button_mc():
        global CalcMemory
        global Memlist
        CalcMemory= 0
        for widget in myFrame2.winfo_children():
            widget.destroy()

        Memlist.clear()
        
    ButtonMC = Button(Frame0, text="MC", width=4, command=button_mc).grid(row=1, column=0, padx=1)
    ButtonMR = Button(Frame0, text="MR",  width=4, command=button_MR).grid(row=1, column=1, padx=1)
    ButtonMplus = Button(Frame0, text="M+", width=4, command=button_Mplus ).grid(row=1, column=2, padx=1)
    ButtonMminus = Button(Frame0, text="M-", width=4, command=button_Mminus ).grid(row=1, column=3, padx=1)
    ButtonMS = Button(Frame0, text="MS", width=4, command=button_MS ).grid(row=1, column=4, padx=1)
    ButtonMstar = Button(Frame0, text="M*", width=4, command=button_Mstar ).grid(row=1, column=5, padx=1)

    def button_action(action):
        global m_num
        global result
        
        if result=="non":
            m_num = entry_field.get()
            entry_field.delete(0, END)
        else:
            number_current = entry_field.get()
            entry_field.delete(0, END)
            if result=="addition":
                m_num=(float(m_num) + float(number_current))
            if result=="subtraction":
                m_num=(float(m_num) - float(number_current))
            if result=="devision":
                m_num=(float(m_num) / float(number_current))
            if result=="multiplication":
                m_num=(float(m_num) * float(number_current))
            if result=="%":
                m_num=(float(m_num) * float(number_current)/100)
        result=action
        print(m_num)
        entry_field.insert(0,0)
    def button_click(number):
        global done
        if float(entry_field.get())==0 or done==1:
            entry_field.delete(0, END)
        current=entry_field.get()
        entry_field.delete(0, END)
        entry_field.insert(0, str(current) +str(number))
        done=0
    def button_clear():
        entry_field.delete(0, END)
        entry_field.insert(0,0)
        global m_num
        global result
        m_num = 0
        result="non"
    def button_equal():
        global done
        global result
        done=1
        global m_num
        number_current = entry_field.get()
        if result=="addition":
            m_num=(float(m_num) + float(number_current))
        if result=="subtraction":
            m_num=(float(m_num) - float(number_current))
        if result=="devision":
            m_num=(float(m_num) / float(number_current))
        if result=="multiplication":
            m_num=(float(m_num) * float(number_current))
        if result=="%":
            m_num=(float(m_num) * float(number_current)/100)
        result="non"
        entry_field.delete(0, END)
        entry_field.insert(0, m_num)
    def button_sqr():
        number_current = entry_field.get()
        entry_field.delete(0, END)
        entry_field.insert(0, float(number_current)**2)
    def button_root():
        number_current = entry_field.get()
        entry_field.delete(0, END)
        entry_field.insert(0, float (number_current)**0.5)
    def button_clear_number_current():
        entry_field.delete(0, END)
        entry_field.insert(0,0)
    def button_percent():
        number_first = entry_field.get()
        global m_num
        global action
        action="%"
        m_num = float(number_first)
        entry_field.delete(0, END)
        entry_field.insert(  )
    def button_back():
        p=entry_field.get()
        entry_field.delete((len(p)-1),END)
        if len(p)==1:
            entry_field.insert(0,0)
    def button_OneX():
        number_current = entry_field.get()
        entry_field.delete(0, END)
        entry_field.insert(0, 1 / float(number_current))
    def button_PlusMin():
        number_current = entry_field.get()
        entry_field.delete(0, END)
        entry_field.insert(0, float (number_current)*-1)
    
    Frame=LabelFrame(calculate, padx=5,pady=5)
    Frame.grid(row=3, column=0)
    myFrame2=LabelFrame(calculate, bg='green', text="Last 5 saved values",bd=5)

    ButtonPer = Button(Frame, text="%", width=6, command=button_percent).grid(row=2, column=0, padx=3)
    ButtonCE = Button(Frame, text="CE", width=6, command=button_clear_number_current).grid(row=2, column=1, padx=3)
    ButtonC = Button(Frame, text="C",  width=6, command=button_clear).grid(row=2, column=2, padx=3)
    ButtonBack = Button(Frame, text="\u232b", width=6,command=button_back).grid(row=2, column=3, padx=3)

    Button1x = Button(Frame, text="1/x", width=6,command=button_OneX ).grid(row=3, column=0)
    Buttonsquer = Button(Frame, text="x\u00b2",  width=6,command=button_sqr).grid(row=3, column=1)
    ButtonRoot = Button(Frame, text="\u221ax",  width=6,command=button_root ).grid(row=3, column=2)
    ButtonDev = Button(Frame, text=":", width=6,command=lambda: button_action("devision") ).grid(row=3, column=3)

    Button7 = Button(Frame, text="7", width=6, command=lambda: button_click(7)).grid(row=4, column=0)
    Button8 = Button(Frame, text="8", width=6, command=lambda: button_click(8)).grid(row=4, column=1)
    Button9 = Button(Frame, text="9", width=6, command=lambda: button_click(9)).grid(row=4, column=2)
    ButtonMult = Button(Frame, text="x", width=6 ,command=lambda: button_action("multiplication")).grid(row=4, column=3)

    Button4 = Button(Frame, text="4", width=6, command=lambda: button_click(4)).grid(row=5, column=0)
    Button5 = Button(Frame, text="5", width=6, command=lambda: button_click(5)).grid(row=5, column=1)
    Button6 = Button(Frame, text="6", width=6, command=lambda: button_click(6)).grid(row=5, column=2)
    ButtonMinuss = Button(Frame, text="-", width=6,command=lambda: button_action("subtraction")).grid(row=5, column=3)

    Button1 = Button(Frame, text="1", width=6 , command=lambda: button_click(1)).grid(row=6, column=0)
    Button2 = Button(Frame, text="2", width=6 , command=lambda: button_click(2)).grid(row=6, column=1)
    Button3 = Button(Frame, text="3", width=6 , command=lambda: button_click(3)).grid(row=6, column=2)
    ButtonAdd = Button(Frame, text="+", width=6 , command=lambda: button_action("addition")).grid(row=6, column=3) 

    ButtonPlusMin = Button(Frame, text="+/-", width=6,command=button_PlusMin ).grid(row=7, column=0)
    Button0 = Button(Frame, text="0",  width=6 ,command=lambda: button_click(0)).grid(row=7, column=1)
    ButtonDot = Button(Frame, text=".", width=6 ,command=lambda: button_click(".")).grid(row=7, column=2)
    ButtonEqual = Button(Frame, text="=", width=6, command=button_equal ).grid(row=7, column=3)
    x=Frame.winfo_height()
def covid():
    Covid = ASwin(root) #setup window
    Covid.configure(background="light grey") #configure background
    Covid.title("Covid") #set tittle
    Covid.geometry("650x950") #set window size
    Coldlist =["Sneezing", "Aches and pains", "Runny or stuffy nose", "Sore throat"] #creat list with cold symtoms
    Fluelist =["Fatigue", "Aches and pains", "Headaches"] #creat list with Flues symtoms
    Covlist=["Sneezing", "Runny or stuffy nose", "Diarrhea"] #creat list with symtoms which allmost never came with covid
    global positive
    positive=0 #Count number of answers "yes" on quiz questions
    global NewQuiz
    global counter
    counter=0 #Count number of answers on quiz questions
    def diagnoses_pos(): #set function name
        global positive #pas argument value outside the function
        positive+=1 #if answer on quiz positive add 1
        quiz() #run next quiz question
    def quiz(): #set function name
        global positive #pas argument value outside the function
        global msgw #pas argument value outside the function
        global z #pas argument value outside the function
        global counter #pas argument value outside the function
        global diagnose #pas argument value outside the function
        global NewQuizWin #pas argument value outside the function
        counter+=1  #count number of answered questions from quiz
        if len(z)==(counter): # check does the user answer all questions from list
            if positive>1: #statment if almost all answers were positive
                if z==Fluelist: # check if answers was given to check Flue symtoms
                    diagnose="Proberly you have flue" #giving diagnose flue
                elif z==Coldlist: # check if answers was given to check Cold symtoms
                    diagnose="Proberly you have cold" #giving diagnose Cold
            else: #statment if almost all answers were negative 
                if z==Covlist: #Check if answers was for Symtoms which ussualy don't have covid patients 
                    diagnose="Proberly you have covid"  #giving diagnose covid
                else:
                    diagnose="You don't have corona virus" #giving diagnose that user don't have covid
            positive=0 #reset variable for new test
            counter=0 # reset variable for new test
            NewQuizWin.destroy() #close quiz
            diagnose_end() #call function with diagnose
            
        else:
            msgw.config(text=("do you have fallowing symtom:" + z[counter])) #ask question from list
    def NewQuiz(): #run quiz with qustion from the one of the 3 lists
        global msgw #Use varibale outside function
        global z #Use varibale outside function
        global NewQuizWin
        NewQuizWin = Toplevel(Covid) #set new window ontop main window
        NewQuizWin.title("Please answer few questions") #set tittle for new window
        NewQuizWin.geometry('500x100') #set size of new window
        msgw=Label(NewQuizWin,text=("Do you have fallowing symtom:" + z[counter]), font="Arial 15", fg="red" , width=40) #ask first question
        msgw.grid(column=1,padx=10,pady=5,sticky=NSEW,columnspan=2)  #set position for questions in the window
        button1=Button(NewQuizWin,text='Yes', command=diagnoses_pos) #set button for answer yes
        button1.grid(column=1,row=1,padx=5,pady=5,sticky=NSEW) #set postion for answer yes
        button2=Button(NewQuizWin,text='No' ,command=quiz) #set button for answer no
        button2.grid(column=2,row=1,padx=5,pady=5,sticky=NSEW) #set postion for answer no




    def description(x): #set function name
        if x=="1":     #check which button is was pressed   
            titl="Cough" #set title for field
            ltext="A new, continuous cough this means coughing a lot for more than an hour, or 3 or more coughing episodes in 24 hours (if you usually have a cough, it may be worse than usual)"      
        elif x=="2":  #check which button is was pressed 
            titl="Loss of sense" #set title for field
            ltext="A loss or change to your sense of smell or taste this means you've noticed you cannot smell or taste anything, or things smell or taste different to normal"
        elif x=="3": #check which button is was pressed
            titl="Fewer" #set title for field
            ltext="A high temperature – this means you feel hot to touch on your chest or back (you do not need to measure your temperature)"
        messagebox.showinfo(title=titl, message=ltext,   )
        







    def print_frame(): #assign function name
        global diagnose  #pass variable values outside function
        global msgw #pass variable values outside function
        global NewQuiz #pass variable values outside function
        global z #pass variable values outside function
        if (var1.get() == 1) and (var2.get() == 1) and (var3.get() == 1) : #if all main simtoms positve give diagnose strait
            diagnose='''You have corona Viruse, please .do the COV-19 test asap''' # Give diagnose
            diagnose_end() # run diagnose function
        elif (var1.get() == 0) and (var2.get() == 0) and (var3.get() == 0) : # if all answers negative, give negative answer strait
            diagnose='''You don't have corona virus''' # Give diagnose
            diagnose_end() # run diagnose function
        elif (var1.get() == 1) and (var2.get() == 1) and (var3.get() == 0): # based on answers it could be covid or flue
            z=Fluelist #set list with symtoms for quiz
            NewQuiz() #run quiz to check is it cold or covid
        elif (var1.get() == 0) and (var2.get() == 0) and (var3.get() == 1): # based on answers it could be covid or somthing else
            z=Covlist # set list for quiz
            NewQuiz() #run quiz
        else:
            z=Coldlist # based on answers it could be cold, set list to chech for cold
            NewQuiz() # run quiz
            
    def diagnose_end(): # set function name 
        
        global diagnose # make varibale visiable inside function
        messagebox.showinfo(title='Diagnose', message=diagnose )
    

        
        


    # set varibales vor radio buttons
    var1 = IntVar()
    var2 = IntVar()
    var3 = IntVar()
    # set label for radio buttons
    Label_test=Label(Covid, text="Check the boxes below, if you have any of following symtoms\n if you don't have any then leave box empty\n then press button 'DONE' to continue",font="Arial",fg="green" )
    Label_test.grid(row=0, column=2, pady=10)
    # creat radio buttons
    c1 = Checkbutton(Covid, text='',variable=var1, onvalue=1, offvalue=0 , bg="light grey")
    c1.grid(row=1, column=0)
    c2 = Checkbutton(Covid, text='',variable=var2, onvalue=1, offvalue=0, bg="light grey")
    c2.grid(row=2, column=0)
    c3 = Checkbutton(Covid, text='',variable=var3, onvalue=1, offvalue=0, bg="light grey")
    c3.grid(row=3, column=0)
    #set buttons to for symtoms description, and make event when mouse on to change button text color 
    ButtonCough = Button(Covid, text="Continoes cough", width=20, highlightthickness = 0, bd = 0, bg="light grey", font="arial", fg='red', command=lambda: description("1"))
    ButtonCough.bind("<Enter>", lambda event: event.widget.config(bg="navy", fg="white"))
    ButtonCough.bind("<Leave>", lambda event: event.widget.config(bg="light grey", fg="navy"))
    ButtonCough.grid(row=1, column=1)
    ButtonTemp = Button(Covid, text="High temperature",  width=20, highlightthickness = 0, bd = 0, bg="light grey", font="arial", fg='red', command=lambda: description("3"))
    ButtonTemp.bind("<Enter>", lambda event: event.widget.config(bg="navy", fg="white"))
    ButtonTemp.bind("<Leave>", lambda event: event.widget.config(bg="light grey", fg="navy"))
    ButtonTemp.grid(row=2, column=1)
    ButtonSmell = Button(Covid, text="Lost of sence and smell",width=20, highlightthickness = 0, bd = 0, bg="light grey", font="arial", fg='red', command=lambda: description("2"))
    ButtonSmell.bind("<Enter>", lambda event: event.widget.config(bg="navy", fg="white"))
    ButtonSmell.bind("<Leave>", lambda event: event.widget.config(bg="light grey", fg="navy"))
    ButtonSmell.grid(row=3, column=1)


    #set images for radio buttons
    global caugh
    global temperature
    global sence
    caugh = PhotoImage(file='img/caugh.png')         
    imgLabel = Label(Covid,image=caugh)        
    imgLabel.grid(row=1, column=2)
    temperature = PhotoImage(file='img/temperature.png')            
    imgLabel = Label(Covid,image=temperature)        
    imgLabel.grid(row=2, column=2)
    sence = PhotoImage(file='img/sence.png')            
    imgLabel = Label(Covid,image=sence)        
    imgLabel.grid(row=3, column=2)


    space=Label(Covid, bg="light grey").grid(row=4,column=2)
    button_done = Button(Covid, text="DONE", command=print_frame)  # set button to run function and collect information from radio buttons
    button_done.grid(row=5, column=2) #set position for button


def abountme():
    abount=ASwin(root)
    abount.title("Abount") #set tittle
    abount.geometry("450x300") #set window size

    Label_abount=Label(abount, text='''

    Created by StArt Ltd
    Date: 24/05/2021 - 28/06/201 

    Version: 1.0b
    Copyrights: StArt Ltd

    Created for course software devolepment level 2 diploma
    Tutor: Ronnie Bruno
    Main program: Covid
    '''
    ,font="Arial",fg="green" )
    Label_abount.grid(row=0, column=2, pady=10)

def helpinfo():
    strURL="https://elattlearning.com/Help/helpfileArturs.pdf"
    webbrowser.open(strURL, new=2)


def exit():
    root.destroy()

menubar=Menu(root,background="pink",foreground="red",activebackground="white", activeforeground="black")
file=Menu(menubar,tearoff="1",background="white",foreground="purple")

file.add_command(label="calculator", command=calculator)
file.add_command(label="search")
file.add_command(label="covid-19", command=covid)
file.add_separator()

edit=Menu(menubar,tearoff="1",background="white",foreground="purple")
edit.add_command(label="Help", command=helpinfo)
edit.add_command(label="About us", command=abountme)
edit.add_separator()

menubar.add_cascade(label="File",menu=file)
menubar.add_cascade(label="info",menu=edit)
menubar.add_command(label="Exit",command=exit)


animation = PhotoImage(file='img/Animation.gif' , format="gif")            
imgLabel = Label(root,image=animation)        
imgLabel.grid(row=1, column=2)



root.config(menu=menubar)
root.mainloop()